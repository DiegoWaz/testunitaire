<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * User_model class.
 * 
 * @extends CI_Model
 */
class Games_model extends CI_Model {

	/**
	 * __construct function.
	 * 
	 * @access public
	 * @return void
	 */
	public function __construct() {
		
		parent::__construct();
		$this->load->database();
	}

	public function lastGame($id) {
	
		$this->db->select('*');
		$this->db->from('games');

		$where = "id_home=$id OR id_away=$id";
		$this->db->where($where);

		$query = $this->db->get();

	   return $query->last_row();
	}	

	public function listGame($id) {
	
		$this->db->select('*');
		$this->db->from('games');

		$where = "id_home=$id OR id_away=$id";
		$this->db->where($where);

		$query = $this->db->get();

	   return $query->result_array();
	}

	public function team($id) {
	
		$this->db->select('*');
		$this->db->from('clubs');

		$where = "id=$id";
		$this->db->where($where);

		$query = $this->db->get();

	   return $query->last_row();
	}	

	public function player($id) {
	
		$this->db->select('*');
		$this->db->from('players');

		$where = "id=$id";
		$this->db->where($where);

		$query = $this->db->get();

	   return $query->last_row();
	}

	public function listPlayerTeam($id) {
	
		$this->db->select('*');
		$this->db->from('players');

		$where = "clubactuel=$id";
		$this->db->where($where);

		$query = $this->db->get();

	   return $query->result_array();
	}	

	public function listGameTeam($id, $limit) {
	
		$this->db->select('*');
		$where = "id_home=$id OR id_away=$id";
		$this->db->where($where);

		$query = $this->db->get("games", $limit);

	   return $query->result_array();
	}

	public function postPlayer($id) {
	
		$this->db->select('*');
		$this->db->from('players');

		$where = "id=$id";
		$this->db->where($where);

		$query = $this->db->get();

	   return $query->result_array();
	}

	public function stats($idGame, $idTeam) {
	
		$this->db->select('*');
		$this->db->from('GameStats');

		$where = "id_match=$idGame AND id_team=$idTeam";
		$this->db->where($where);

		$query = $this->db->get();

	   return $query->result_array();
	}

	public function getNameTeam($id) {
		
		$this->db->select('name');
		$this->db->from('clubs');
		$this->db->where('id', $id);

		$query = $this->db->get();

		return $query->row("name");
		
	}

	public function getAbbreviationTeam($id) {
		
		$this->db->from('clubs');
		$this->db->where('id', $id);

		$query = $this->db->get();

		return $query->row("abbreviation");
		
	}	

	public function getListPlayers() {
		
		$this->db->select('*');
		$this->db->from('players');

		$query = $this->db->get();

		return $query->result_array();
		
	}		

	public function getListGames() {
		
		$this->db->select('*');
		$this->db->from('games');

		$query = $this->db->get();

		return $query->result_array();
		
	}	

	public function getListClubs() {
		
		$this->db->select('*');
		$this->db->from('clubs');

		$query = $this->db->get();

		return $query->result_array();
		
	}


}