<!-- BEGIN SIDEBAR -->
<div class="page-sidebar " id="main-menu">
    <!-- BEGIN MINI-PROFILE -->
    <div class="page-sidebar-wrapper scrollbar-dynamic" id="main-menu-wrapper">
        <div class="user-info-wrapper sm">
            <div class="profile-wrapper sm">
                <img src="<?php echo base_url(); ?>assets/back/img/profiles/avatar.jpg" alt="" data-src="<?php echo base_url(); ?>assets/back/img/profiles/avatar.jpg" data-src-retina="<?php echo base_url(); ?>assets/back/img/profiles/avatar2x.jpg" width="69" height="69" />
                <div class="availability-bubble online"></div>
            </div>
            <div class="user-info sm">
                <div class="username">Diegowaz75</div>
                <div class="status">Connecté</div>
            </div>
        </div>

        <p class="menu-title sm">BROWSE <span class="pull-right"><a href="javascript:;"><i class="material-icons">refresh</i></a></span></p>

        <ul>
            <li>
                <a href="javascript:;"> <i class="fa fa-newspaper-o"></i> <span class="title">News</span></a>
                <ul class="sub-menu">
                    <li>
                        <a href="<?php echo base_url(); ?>back/Listnews">Liste des articles</a>
                    <li>
                        <a href="<?php echo base_url(); ?>back/sectionList">Liste des sections</a>
                    <li>
                        <a href="<?php echo base_url(); ?>back/rubriqueList">Liste des rubriques</a>
                    <li>
                        <a href="<?php echo base_url(); ?>back/storyList">Liste des Stories</a>
                    <li>
                        <a href="<?php echo base_url(); ?>back/mercatoList">Liste des feuilletons mercato</a>
                    <li>
                        <a href="<?php echo base_url(); ?>back/events">Évènements</a>
                </ul>
            <li>
                <a href="#"><i class="fa fa fa-line-chart"></i><span class="title">Stats</span></a>
                <ul class="sub-menu">
                    <li>
                        <a href="#">Pages vues</a></li>
                    <li>
                        <a href="#">Classement des rédacteurs</a></li>
                    <li>
                        <a href="#">Rédacteur du mois</a>
                    </li>
                </ul>       
            <li>
                <a href="#"><i class="fa fa-futbol-o"></i> <span class="title">Foot</span></a>
                <ul class="sub-menu">
                    <li>
                        <a href="">Joueurs</a>
                    <li>
                        <a href="">Clubs</a>
                    <li>
                        <a href="">Matchs</a>
                    <li>
                        <a href="">Compétitions</a>
                    <li>
                        <a href="">Saisons</a>
                    <li>
                        <a href="">Stades</a>
                </ul>
            <li>
                <a href="#"><i class="fa fa-comments"></i> <span class="title">Commentaires</span></a>
                <ul class="sub-menu">
                    <li>
                        <a href="">Tous les commentaires</a>
                    <li>
                        <a href="">Signaler les commentaires</a>
                </ul>
                    
            <li>
                <a href="#"><i class="fa fa-cog"></i> <span class="title">Site</span></a>
                <ul class="sub-menu">
                    <li>
                        <a href="">Configuration</a>
                    <li>
                        <a href="">Menu</a>
                    <li>
                        <a href="">Publicité</a>
                    <li>
                        <a href="">Traduction</a>
                </ul>
        </ul>
        <div class="clearfix"></div>
        <!-- END SIDEBAR MENU -->
    </div>
</div>
<a href="#" class="scrollup">Scroll</a>
<div class="footer-widget">
    <div class="pull-right">
        <a href="lockscreen.html"><i class="material-icons">power_settings_new</i></a></div>
    </div>
<!-- END SIDEBAR -->