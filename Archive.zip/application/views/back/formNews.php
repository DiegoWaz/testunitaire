<?php 
header('Location: ' . base_url()."back/index");
?>