<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="kode-subheader subheader-height">
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<h1>S'inscrire</h1>
			</div>
			<div class="col-md-6">
				<ul class="kode-breadcrumb">
					<li><a href="#">Accueil</a></li>
					<li><a href="#">S'inscrire</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
    
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="page-header">
				<h1>Thank you for registering your new account!</h1>
			</div>
			<p>You have successfully register. Please check your email inbox to confirm your email address.</p>
		</div>
	</div><!-- .row -->
</div><!-- .container -->