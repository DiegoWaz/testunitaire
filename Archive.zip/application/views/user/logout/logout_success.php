<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="kode-subheader subheader-height">
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<h1>Connexion</h1>
			</div>
			<div class="col-md-6">
				<ul class="kode-breadcrumb">
					<li><a href="#">Accueil</a></li>
					<li><a href="#">Connexion</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
    
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="page-header">
				<h1>Logout success!</h1>
			</div>
			<p>You are now logged out.</p>
		</div>
	</div><!-- .row -->
</div><!-- .container -->