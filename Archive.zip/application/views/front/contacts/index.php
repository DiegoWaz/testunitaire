<div class="kode-subheader subheader-height">
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<h1>Contact Us</h1>
			</div>
			<div class="col-md-6">
				<ul class="kode-breadcrumb">
					<li><a href="#">Home</a></li>
					<li><a href="#">Blog</a></li>
					<li><a href="#">Contact Us</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
<!--// SubHeader //-->

<!--// Main Content //-->
<div class="kode-content">

	<!--// Page Content //-->
	<section class="kode-pagesection">
		<div class="container">
			<div class="row">
				<div class="kode-pagecontent col-md-12">
					<div class="contactus-page">
						<div class="row">
							<div class="col-md-6">
								<div class="kode-simple-form">  					
									<form method="post" class="comments-form" id="contactform">
										<ul>
											<li><input type="text" id="name" name="name" class="required" placeholder="Name *"></li>
											<li><input type="text" id="email" name="email" class="required email" placeholder="Email *"></li>
											<li><input type="text" name="address" id="address" placeholder="Address:"></li>
											<li><textarea name="message" id="message" placeholder="add your message"></textarea></li>
											<li>
												<label for="verify">Are you human?</label>
												<input class="verify" type="text" id="verify" name="verify" />
											</li>
											<li><input class="thbg-color" type="submit" value="send"></li>
										</ul>
									</form>
								</div>
							</div>
							<div class="col-md-6">
								<div class="kode-section-title"> <h2>Contact Info</h2> </div>
								<div class="kode-forminfo">
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip..</p>
									<ul class="kode-form-list">
										<li><i class="fa fa-home"></i> <p><strong>Address:</strong> 805 omnis iste natus error sit voluptatem accusantium</p></li>
										<li><i class="fa fa-phone"></i> <p><strong>Phone:</strong> 111 8756 22  777 4456 112</p></li>
										<li><i class="fa fa-envelope-o"></i> <p><strong>Email:</strong> Info@sportyleague.com</p></li>
									</ul>
									<h3>Find Us On</h3>
									<ul class="kode-team-network">
										<li><a href="#" class="fa fa-facebook"></a></li>
										<li><a href="#" class="fa fa-twitter"></a></li>
										<li><a href="#" class="fa fa-linkedin"></a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>

				</div>

			</div>
		</div>
	</section>
	<!--// Page Content //-->

</div>
<!--// Main Content //-->