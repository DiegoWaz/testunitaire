<div id="mainbanner">
	<div class="flexslider">
		<ul class="slides">
			<?php
			foreach ($une as $articleUne):
                ?>
				<li>
					<img src="<?php echo $articleUne["image"]; ?>" alt="<?php echo $articleUne["title"]; ?>" />
					<div class="container">
						<div class="kode-caption">       
							<h1>
								<a href="news/<?php echo $articleUne["slug"]; ?>">
									<?php echo $articleUne["title"]; ?>
								</a>	
							</h1>
							<div class="clearfix"></div>        
							<p><?php echo $articleUne["resume"]; ?></p>
							<div class="clearfix"></div>
						</div>
					</div>
				</li>
				<?php
			endforeach;
			?>
		</ul>
	</div>
</div>

<div class="kode-content">
	<section class="pick-event padding-30-topbottom margin-top-minus-40">
		<div class="container">
			<div class="row">
				<div class="col-md-3">
					<?php $this->view('front/news/aside_news'); ?>
				</div>
				<div class="kode-pagecontent col-md-9">
					<div class="kode-blog-list kode-grid-blog">
						<ul class="row">
							<?php
							foreach ($listeRubrique as $key => $lRubrique):
							?>
							<div class="col-md-12 kode-section-title"> 
								<h2>Les <?php echo $lRubrique; ?></h2>
							</div>
							<?php
							
							$list_news_rubrique = $this->news_model->get_list_news_rubrique($key, 3);

							foreach ($list_news_rubrique as $news):
                                if($key == $news["rubrique"]):
                                    if($news["date"] < time()):
								?>
								<li class="col-md-4">
									<div class="kode-time-zoon"></div>
									<figure>
										<a href="<?php echo base_url(); ?>news/view/<?php echo $news["slug"]; ?>">
											<img src="<?php echo $news["image"]; ?>" alt="<?php echo $news["title"]; ?>">
										</a>
									</figure>
									<div class="kode-blog-info">
										<time datetime="<?php echo $news["updated_at"]; ?>">
                                            <span>
                                                <?php

                                                $datenews = date("d-m-Y", $news["date"]);

                                                if($datenews == $this->today):
                                                    echo "Aujourd'hui";
                                                elseif($datenews == $this->yesterday):
                                                    echo "Hier";
                                                elseif($datenews == $this->tommorow):
                                                    echo "Demain";
                                                else:
                                                    echo date("d/m/Y", $news["date"]);
                                                endif;
                                                echo date(" à h:i", $news["date"]);
                                                ?>
                                            </span>
                                        </time>
										<h3><a href="<?php echo base_url(); ?>news/view/<?php echo $news["slug"]; ?>"><?php echo $news["title"]; ?></a></h3>

										<p><?php echo $news["resume"]; ?></p>

										<div class="clearfix"></div>
										<ul class="kode-team-network">
											<li>
												<a target="_blank" class="fa fa-facebook" href="http://www.facebook.com/sharer.php?u=<?php echo base_url(); ?>news/view/<?php echo $news["slug"]; ?>"></a>
											</li>
											<li>
												<a target="_blank" class="fa fa-twitter" href="https://twitter.com/intent/tweet?text=<?php echo utf8_decode($news["title"]); ?> @LMDPSG <?php echo base_url(); ?>news/view/<?php echo $news["slug"]; ?>"></a>
											</li>
										</ul>
									</div>
								</li>
								<?php
									endif;
                                endif;
							endforeach;
							?>
							<div class="kode-align-btn">
								<a href="#" class="kode-modren-btn thbg-colortwo">Tous les <?php echo $lRubrique; ?></a>
							</div>
							<?php
							endforeach;
							?>
						</ul>
					</div>
				</div>
			</div>
		</section>		

		<!--// Page Content //-->
		<section class="kode-pagesection padding-30-topbottom bg-white">
			<div class="container">
				<div class="row">

					<div class="kode-result-list shape-view col-md-12">
						<div class="heading heading-12 margin-top30-bottom80">
							<h2><span class="left"></span>Le match précédent <span class="right"></span></h2>
						</div>
						<div class="clear clearfix"></div>
						<div class="row">
							<div class="col-md-6">
								<article>
									<span class="kode-result-count thbg-colortwo"><?php echo $lastgame->score_home; ?></span>
									<div class="kode-result-thumb">
										<a href="#">
											<img src="assets/images/clubs/<?php echo $clubHome->image; ?>" alt="<?php echo $clubHome->name; ?>">
										</a>
									</div>
									<div class="kode-result-info">
										<h2><a href="#">Buteurs</a></h2>
										<ul>
											<?php
											foreach ($statsHome as $goal):
												$buteur = $this->games_model->player($goal['id_player']);
											?>
											<li>
												<?php echo $buteur->number; ?> - <?php echo $buteur->firstname.' '.$buteur->lastname; ?>
											</li>
											<?php
											endforeach;
											?>
										</ul>
									</div>
								</article>
							</div>
							<div class="col-md-6">
								<article class="kode-even">
									<span class="kode-result-count thbg-colortwo"><?php echo $lastgame->score_away; ?></span>
									<div class="kode-result-thumb">
										<a href="#">
											<img src="assets/images/clubs/<?php echo $clubAway->image; ?>" alt="<?php echo $clubAway->name; ?>">
										</a>
									</div>
									<div class="kode-result-info">
										<h2><a href="#">Buteurs</a></h2>
										<ul>
											<?php
											foreach ($statsAway as $goal):
												$buteur = $this->games_model->player($goal['id_player']);
											?>
											<li>
												<?php echo $buteur->number; ?> - <?php echo $buteur->firstname.' '.$buteur->lastname; ?>
											</li>
											<?php
											endforeach;
											?>
										</ul>
									</div>
								</article>
							</div>
						</div>
					</div>

				</div>
			</div>
		</section>
		<!--// Page Content //-->

		<div class="pick-event kode-pagecontent col-md-12">
			<div class="container kode-blog-list kode-grid-blog">
				<ul class="row">
					<div class="col-md-4 kode-section-title"> 
						<h2>L'histoire du PSG</h2>
					</div>
					<?php
					foreach ($list_contenue as $contenue):
						?>
						<li class="col-md-4">
							<div class="kode-time-zoon"></div>
							<figure><a href="#"><img src="<?php echo $contenue["image"]; ?>" alt=""></a></figure>
							<div class="kode-blog-info">
								<time datetime="<?php echo $contenue["updated_at"]; ?>">
									<?php
                                        $datenews = date("d-m-Y", $contenue["date"]);

                                        if($datenews == $this->today):
                                            echo "Aujourd'hui";
                                        elseif($datenews == $this->yesterday):
                                            echo "Hier";
                                        elseif($datenews == $this->tommorow):
                                            echo "Demain";
                                        else:
                                            echo date("d/m/Y", $news["date"]);
                                        endif;
                                        echo date(" à h:i", $news["date"]);
                                        ?>
								</time>
								<h3><a href="#"><?php echo $contenue["title"]; ?></a></h3>

								<div class="clearfix"></div>
								<ul class="kode-team-network">
									<li>
										<a target="_blank" class="fa fa-facebook" href="http://www.facebook.com/sharer.php?u=<?php echo base_url(); ?>news/view/<?php echo $contenue["id"]; ?>"></a>
									</li>
									<li>
										<a target="_blank" class="fa fa-twitter" href="https://twitter.com/intent/tweet?text=<?php echo $contenue["title"]; ?> @LMDPSG <?php echo base_url(); ?>news/view/<?php echo $contenue["id"]; ?>"></a>
									</li>
								</ul>
							</div>
						</li>
					<?php
					endforeach;
					?>
					<li class="clearfix"></li>
				</ul>
			</div>
		</div>

		
		<!--// Page Content //-->
		<section class="kode-pagesection kode-sport-section kode-parallax">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="heading heading-12 margin-top5-bottom10-flat">
							<h2><span class="left"></span>Prochain match dans<span class="right"></span></h2>
						</div>
						<div class="kode-fixer-counter">
							<div id="kodeCountdown"></div>
						</div>
						<div class="kode-team-match">
							<ul>
								<li><a href="#"><img src="http://medias.lequipe.fr/logo-football/26/100" alt=""></a></li>
								<li class="home-kode-vs"><a href="#" class="kode-modren-btn thbg-colortwo">vs</a></li>
								<li><a href="#"><img src="http://medias.lequipe.fr/logo-football/71/100" alt=""></a></li>
							</ul>
							<div class="clearfix"></div>
							<span class="kode-subtitle">Parc des Princes, mardi 13 septembre 2016 - 21:00 <br>beIN SPORTS</span>
						</div>

					</div>
				</div>
			</div>
		</section>
		<!--// Page Content //-->
		
		<!--// Page Content //-->
		<section class="kode-pagesection top_player_section" >
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="kode-section-title"> <h2>Effectif & Staff</h2> </div>
						<div class="owl-carousel-team owl-theme kode-team-list next-prev-style">
							<?php 
							foreach ($players as $player):
							?>
							<div class="item">
								<figure><a href="#" class="kode-team-thumb"><img src="<?php echo $player['image']; ?>" alt="<?php echo $player['lastname']; ?>"></a>
									<figcaption>
										<ul class="kode-team-network">
											<li><a href="#" class="fa fa-facebook"></a></li>
											<li><a href="#" class="fa fa-twitter"></a></li>
											<li><a href="#" class="fa fa-linkedin"></a></li>
										</ul>
										<div class="clearfix"></div>
										<h2><a href="<?php echo base_url()."joueur/".$player['id'] ?>"><span><?php echo $player['number']; ?></span> <?php echo $player['firstname'].' '.$player['lastname']; ?></a></h2>
									</figcaption>
								</figure>
							</div>
							<?php 
						endforeach;
							?>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!--// Page Content //-->
		
		<div class="kd-pagesection project_fact_inline">
			<div class="container">
				<div class="row">

					<div class="col-md-12">

						<!--// Counter Section //-->
						<div class="kd-counter">
							<ul class="row">
								<li class="col-md-3">
									<i class="fa fa-soccer-ball-o fa-3x"></i>
									<span class="word-count"><?php echo $countNews; ?></span>
									<small>Articles</small>
								</li>
								<li class="col-md-3">
									<i class="fa fa-user fa-3x"></i>
									<span class="word-count"><?php echo $countPlayers; ?></span>
									<small>Joueurs</small>
								</li>
								<li class="col-md-3">
									<i class="fa fa-users fa-3x"></i>
									<span class="word-count"><?php echo $countTeams; ?></span>
									<small>Clubs</small>
								</li>
								<li class="col-md-3">
									<i class="fa fa-soccer-ball-o fa-3x"></i>
									<span class="word-count"><?php echo $countMatchs; ?></span>
									<small>Matchs</small>
								</li>
							</ul>
						</div>
						<!--// Counter Section //-->

					</div>

				</div>
			</div>
		</div>

		<!--// Page Content //-->
		<section class="kode-pagesection kode-next-match-stat" >
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="heading heading-12 margin-top30-bottom10">
							<h2><span class="left"></span>5ème journée de Ligue 1<span class="right"></span></h2>
						</div>
					</div>	
					<div class="col-md-4">
						<table class="kode-table kode-table-v2">
							<thead>
								<tr>
									<th>Équipes</th>
									<th>J</th>
									<th>V</th>
									<th>N</th>
									<th>D</th>
									<th>pts</th>
								</tr>
							</thead>
							<tbody>
								<?php
								for ($i=0; $i < 10; $i++) { 

									?>
									<tr>
										<td>PSG</td>
										<td>15</td>
										<td>11</td>
										<td>02</td>
										<td>00</td>
										<td>42</td>
									</tr>
									<tr>
										<td>Arsenal</td>
										<td>15</td>
										<td>11</td>
										<td>02</td>
										<td>00</td>
										<td>42</td>
									</tr>
									<?php

								}

								?>

							</tbody>
						</table>

					</div>		
					<div class="col-md-8">
						<table class="kode-table">
							<thead>
								<tr>
									<th>Date</th>
									<th>Upcoming Match</th>
									<th>Chaine</th>
								</tr>
							</thead>
							<tbody>
								<?php
								for ($i=0; $i < 10; $i++) { 
									?>

									<tr>
										<td>18/05/2015  14:30 - 16:00</td>
										<td>City Club <span>VS</span>Soccer Queen</td>
										<td>beIN SPORTS</td>
									</tr>

									<?php
								}
								?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</section>
	</div>