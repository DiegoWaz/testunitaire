<div class="kode-subheader subheader-height">
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<h1>Player Detail</h1>
			</div>
			<div class="col-md-6">
				<ul class="kode-breadcrumb">
					<li><a href="#">Home</a></li>
					<li><a href="#">Blog</a></li>
					<li><a href="#">Contact Us</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
<!--// SubHeader //-->

<!--// Main Content //-->
<div class="kode-content">

	<!--// Page Content //-->
	<section class="kode-pagesection">
		<div class="container">
			<div class="row">
				<!-- <div class="col-md-1"></div> -->
				<div class="kode-pagecontent col-md-12">

					<div class="row">
						<div class="col-md-5"><a href="#" class="kode-player-thumb"><img src="extra-images/player-detail-1.jpg" alt=""></a></div>
						<div class="col-md-7">

							<div class="kode-detail-element">
								<h2>Sergio Ramos</h2>
								<ul class="kode-team-network">
									<li><a class="fa fa-facebook" href="#"></a></li>
									<li><a class="fa fa-twitter" href="#"></a></li>
									<li><a class="fa fa-linkedin" href="#"></a></li>
								</ul>
							</div>

							<p>Mauris vel varius felis. Duis feugiat interdum nibh, nec consequat erat dapibus sit amet. Ut at nibh varius, dignissim magna non, interdum urna. Maecenas enean..</p>

							<table class="kode-table">
								<caption>Profile</caption>
								<tbody>
									<tr>
										<td>Born:</td>
										<td>February 14, 1986</td>
									</tr>
									<tr>
										<td>Location:</td>
										<td>Spain</td>
									</tr>
									<tr>
										<td>Squad Number:</td>
										<td>45</td>
									</tr>
									<tr>
										<td>Club:</td>
										<td>AC Millen</td>
									</tr>
									<tr>
										<td>Position:</td>
										<td>Defender</td>
									</tr>
									<tr>
										<td>Previous Club(s):</td>
										<td>Lille, Newcastle United</td>
									</tr>
								</tbody>
							</table>

						</div>
					</div>

					<div class="kode-player-tabs">

						<!-- Nav tabs -->
						<ul class="player-nav" role="tablist">
							<li role="presentation" class="active"><a href="#hometwo" aria-controls="hometwo" role="tab" data-toggle="tab">Appearance 2014-2015</a></li>
							<li role="presentation"><a href="#profiletwo" aria-controls="profiletwo" role="tab" data-toggle="tab">Appearance 2013-2014</a></li>
						</ul>

						<!-- Tab panes -->
						<div class="tab-content">
							<div role="tabpanel" class="tab-pane active" id="hometwo">
								<table class="kode-table">
									<thead>
										<tr>
											<th>Leagues</th>
											<th>Season</th>
											<th>Appearance</th>
											<th>Goal</th>
											<th>Cards Shown</th>
											<th>Passing Accuracy</th>
										</tr>
									</thead>
									<tbody>
										<tr>
											<td>Prem Lge</td>
											<td>2014-2015</td>
											<td>00</td>
											<td>01</td>
											<td>06</td>
											<td>100%</td>
										</tr>
										<tr>
											<td>Europe Lge</td>
											<td>2014-2015</td>
											<td>00</td>
											<td>01</td>
											<td>06</td>
											<td>100%</td>
										</tr>
										<tr>
											<td>Fa Cup</td>
											<td>2014-2015</td>
											<td>00</td>
											<td>01</td>
											<td>06</td>
											<td>100%</td>
										</tr>
										<tr>
											<td>Lge Cup</td>
											<td>2014-2015</td>
											<td>00</td>
											<td>01</td>
											<td>06</td>
											<td>100%</td>
										</tr>
										<tr>
											<td>C. Shield</td>
											<td>2014-2015</td>
											<td>00</td>
											<td>01</td>
											<td>06</td>
											<td>100%</td>
										</tr>
										<tr>
											<td>Total</td>
											<td>2014-2015</td>
											<td>00</td>
											<td>01</td>
											<td>06</td>
											<td>100%</td>
										</tr>
									</tbody>
								</table>
							</div>
							<div role="tabpanel" class="tab-pane" id="profiletwo">
								<table class="kode-table">
									<thead>
										<tr>
											<th>Leagues</th>
											<th>Season</th>
											<th>Appearance</th>
											<th>Goal</th>
										</tr>
									</thead>
									<tbody>
										<tr>
											<td>Prem Lge</td>
											<td>2014-2015</td>
											<td>00</td>
											<td>01</td>
										</tr>
										<tr>
											<td>Europe Lge</td>
											<td>2014-2015</td>
											<td>00</td>
											<td>01</td>
										</tr>
										<tr>
											<td>Fa Cup</td>
											<td>2014-2015</td>
											<td>00</td>
											<td>01</td>
										</tr>
										<tr>
											<td>Lge Cup</td>
											<td>2014-2015</td>
											<td>00</td>
											<td>01</td>
										</tr>
									</tbody>
								</table>
							</div>
						</div>

					</div>

					<div class="kode-editor">
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur."Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
						<blockquote>Nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.Ut enim ad minima veniam, quis nostrum exercitationem </blockquote>
						<p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modification..</p>
					</div>

					<div class="kode-section-title"> <h2>Sergio Ramos PHOTOS & VIDEOS</h2> </div>
					<div class="kode-gallery">
						<ul class="row">
							<li class="col-md-6">
								<figure><a href="#"><img src="http://lmdpsg.com:8888/CodeIgniter/assets/images/news/newsdefault.jpg" alt=""></a>
									<figcaption><a href="#" class="kode-gallery-hover thbg-color"><i class="fa fa-plus"></i></a></figcaption>
								</figure>
								<div class="kode-gallery-info">
									<h2><a href="#">dignissimos ducimus</a></h2>
									<p>Lorem ipsum dolor</p>
								</div>
							</li>
							<li class="col-md-6">
								<figure><a href="#"><img src="http://lmdpsg.com:8888/CodeIgniter/assets/images/news/newsdefault.jpg" alt=""></a>
									<figcaption><a href="#" class="kode-gallery-hover thbg-color"><i class="fa fa-plus"></i></a></figcaption>
								</figure>
								<div class="kode-gallery-info">
									<h2><a href="#">dignissimos ducimus</a></h2>
									<p>Lorem ipsum dolor</p>
								</div>
							</li>
						</ul>
					</div>

					<div id="koderespond">
						<div class="kode-section-title"> <h2>Sergio Ramos PHOTOS & VIDEOS</h2> </div>
						<form>
							<p><input type="text" placeholder="Name *"></p>
							<p><input type="text" placeholder="Phone *"></p>
							<p><input type="text" placeholder="Email *"></p>
							<p class="kd-textarea"><textarea placeholder="add your comment"></textarea></p>
							<p class="kd-button"><input type="button" value="Submit comments" class="thbg-color"></p>
						</form>
					</div>
				</div>
				<!-- <div class="col-md-1"></div> -->
			</div>
		</div>
	</section>
	<!--// Page Content //-->

</div>
<!--// Main Content //-->