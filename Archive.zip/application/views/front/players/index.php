<div class="kode-subheader subheader-height">
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<h1><?php echo $player->number . " " . $player->firstname . " " . $player->lastname; ?></h1>
			</div>
			<div class="col-md-6">
				<ul class="kode-breadcrumb">
					<li><a href="#">Accueil</a></li>
					<li><a href="#">Joueurs</a></li>
					<li><a href="#"><?php echo $player->firstname . " " . $player->lastname; ?></a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
<div class="kode-content">
	<section class="kode-pagesection">
		<div class="container">
			<div class="row">
				<div class="kode-pagecontent col-md-12">
					<div class="row">
						<div class="col-md-3">
							<a href="#" class="kode-player-thumb">
								<img src="<?php echo $player->image; ?>" alt="<?php echo $player->firstname . " " . $player->lastname; ?>">
							</a>
						</div>
						<div class="col-md-9">
							<div class="kode-detail-element">
								<h2><?php echo $player->firstname . " " . $player->lastname; ?></h2>
								<ul class="kode-team-network">
									<li><a class="fa fa-facebook" href="#"></a></li>
									<li><a class="fa fa-twitter" href="#"></a></li>
									<li><a class="fa fa-linkedin" href="#"></a></li>
									<li><a class="fa fa-heart" href="#"></a></li>
								</ul>
							</div>
							<table class="kode-table">
								<caption>Profil</caption>
								<tbody>
									<tr>
										<td>Date de naissance :</td>
										<td><?php echo $player->dateBirthday." à ".$player->cityBirth; ?></td>
									</tr>
									<tr>
										<td>Poste(s) :</td>
										<td><?php echo $player->poste; ?></td>
									</tr>
									<tr>
										<td>Taille :</td>
										<td><?php echo $player->height; ?> cm</td>
									</tr>
									<tr>
										<td>Poids :</td>
										<td><?php echo $player->weight; ?> kg</td>
									</tr>
									<tr>
										<td>Pied :</td>
										<td><?php 
										if($player->foot == 0):
											echo "Droit";
										elseif($player->foot == 1):
											echo "Gauche";
										elseif($player->foot == 2):
											echo "Les deux";
										endif;
										?></td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
					<br>
					<div class="row">
						<div class="col-md-12">
							<div class="kode-player-tabs">
								<!-- Nav tabs -->
								<ul class="player-nav" role="tablist">
									<li role="presentation" class="active"><a href="#hometwo" aria-controls="hometwo" role="tab" data-toggle="tab">Club</a></li>
									<li role="presentation"><a href="#profiletwo" aria-controls="profiletwo" role="tab" data-toggle="tab">Sélection</a></li>
									<li role="presentation"><a href="#profilethree" aria-controls="profilethree" role="tab" data-toggle="tab">Palmarès</a></li>
								</ul>
								<!-- Tab panes -->
								<div class="tab-content">
									<div role="tabpanel" class="tab-pane active" id="hometwo">
										<table class="kode-table">
											<thead>
												<tr>
													<th>Saison(s)</th>
													<th>Club(s)</th>
													<th>Match(s)</th>
													<th>But(s)</th>
													<th>Passe(s) décisive(s)</th>
												</tr>
											</thead>
											<tbody>
												<tr>
													<td>2014-2015</td>
													<td>Paris Saint-Germain</td>
													<td>250</td>
													<td>154</td>
													<td>6</td>
												</tr>
											</tbody>
										</table>
									</div>
									<div role="tabpanel" class="tab-pane" id="profiletwo">
										<table class="kode-table">
											<thead>
												<tr>
													<th>Nation</th>
													<th>Match(s)</th>
													<th>But(s)</th>
													<th>Passe(s) décisive(s)</th>
												</tr>
											</thead>
											<tbody>
												<tr>
													<td>Paris Saint-Germain</td>
													<td>250</td>
													<td>154</td>
													<td>6</td>
												</tr>
											</tbody>
										</table>
									</div>
									<div role="tabpanel" class="tab-pane" id="profilethree">
										<table class="kode-table">
											<thead>
												<tr>
													<th>Année</th>
													<th>Titre</th>
												</tr>
											</thead>
											<tbody>
												<tr>
													<td>2014-2015</td>
													<td>Ligue 1</td>
												</tr>
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
					<hr>
					<div class="row">
						<div class="col-md-3">
							<table class="kode-table">
								<thead>
									<tr>
										<th>Ses coéquipiers</th>
									</tr>
								</thead>
								<tbody>
									<?php foreach ($listTeamMate as $teamMate): ?>
										<tr>
											<td>
												<a href="<?php echo base_url(). 'joueur/'. $teamMate['id']; ?>">
													<?php echo $teamMate['number'].' '.$teamMate['firstname'].' '.$teamMate['lastname']; ?></a>
												</td>
											</tr>
										<?php endforeach; ?>
									</tbody>
								</table>
							</div>
							<div class="col-md-6">

								<div class="comments">
									<div class="sh-add-comment">
										<form action="#"><input type="text" class="form-control ttg-border-none" placeholder="Add a Comment"></form>
										<div class="sh-add-comment__content">
											<a href="#" class="sh-add-comment__btn-save sh-btn-icon"><span>180</span><i class="icon-Submit_Tick"></i></a>
										</div>
									</div>
								</div>

								<div class="pick-event kode-pagecontent col-md-12">
									<div class="container kode-blog-list kode-grid-blog">
										<div class="row">
											<?php
											foreach ($list_news as $news):
												$newsjoueur = explode(",", $news['id_players']);
												foreach ($newsjoueur as $value):
													if($value == $player->id):
														if($news['type_page'] == "Article"):
															?>
															<div class="comments">
																<div class="kode-time-zoon"></div>
																<figure>
																	<a href="#">
																		<img src="<?php echo $news["image"]; ?>" alt="">
																	</a>
																</figure>
																<div class="kode-blog-info">
																	<time datetime="<?php echo $news["updated_at"]; ?>">
																		<?php

																		$datenews = date("d-m-Y", $news["date"]);

																		if($datenews == $this->today):
																			echo "Aujourd'hui";
																		elseif($datenews == $this->yesterday):
																			echo "Hier";
																		elseif($datenews == $this->tommorow):
																			echo "Demain";
																		else:
																			echo date("d/m/Y", $news["date"]);
																		endif;
																		echo date(" à h:i", $news["date"]);
																		?>
																	</time>
																	<h3><a href="<?php echo base_url().'news/'.$news["slug"]; ?>"><?php echo $news["title"]; ?></a></h3>

																	<div class="clearfix"></div>
																	<ul class="kode-team-network">
																		<li>
																			<a target="_blank" class="fa fa-facebook" href="http://www.facebook.com/sharer.php?u=<?php echo base_url(); ?>news/view/<?php echo $news["id"]; ?>"></a>
																		</li>
																		<li>
																			<a target="_blank" class="fa fa-twitter" href="https://twitter.com/intent/tweet?text=<?php echo $news["title"]; ?> @LMDPSG <?php echo base_url(); ?>news/view/<?php echo $news["id"]; ?>"></a>
																		</li>
																	</ul>
																</div>

																<?php		
																foreach ($list_news as $news2):
																	if($news2['type_page'] == "Commentaire"):
																		if($news['id'] == $news2['id_com']):
																			?>
																			<div class="sh-comments__section">
																				<a href="#" class="sh-comments__avatar sh-avatar">
																					<img src="<?php echo base_url()."assets/images/users/neymar.jpg"; ?>" alt="">
																				</a>
																				<div class="sh-comments__content">
																					<a href="#" class="sh-comments__name">DSVUI</a>
																					<span class="sh-comments__passed">. 
																						<?php
																						$datenews = date("d-m-Y", $news2["date"]);

																						if($datenews == $this->today):
																							echo "Aujourd'hui";
																						elseif($datenews == $this->yesterday):
																							echo "Hier";
																						elseif($datenews == $this->tommorow):
																							echo "Demain";
																						else:
																							echo date("d/m/Y", $news2["date"]);
																						endif;
																						echo date(" à h:i", $news2["date"]);
																						?>
																					</span>
																					<p><?php echo $news2["content"]; ?></p>
																					<div class="sh-comments__info">
																						<a href="#" class="sh-section__btn-like sh-btn-icon"> 
																							<i class="fa fa-heart"></i>
																							<span> 1 274</span>
																						</a>
																					</div>
																				</div>
																			</div>
																			<?php 
																		endif;
																	endif;
																endforeach;
																?>

																<div class="sh-add-comment">
																	<form action="#">
																		<input type="text" class="form-control ttg-border-none" placeholder="Add a Comment">
																	</form>
																	<div class="sh-add-comment__content">
																		<a href="#" class="sh-add-comment__btn-save sh-btn-icon"><span>180</span><i class="icon-Submit_Tick"></i></a>
																	</div>
																</div>
															</div>
															<?php
														elseif($news['type_page'] == "Commentaire"):
															?>
															<div class="comments">
																<div class="sh-section">
																	<div class="sh-section__head">
																		<a href="single_post.html" class="sh-section__avatar sh-avatar"><img src="<?php echo base_url()."assets/images/users/neymar.jpg"; ?>" alt=""></a>
																		<div>
																			<a href="#" class="sh-section__name">Diego</a>
																			<span class="sh-section__passed">
																				<?php
																				$datenews = date("d-m-Y", $news["date"]);

																				if($datenews == $this->today):
																					echo "Aujourd'hui";
																				elseif($datenews == $this->yesterday):
																					echo "Hier";
																				elseif($datenews == $this->tommorow):
																					echo "Demain";
																				else:
																					echo date("d/m/Y", $news["date"]);
																				endif;
																				echo date(" à h:i", $news["date"]);
																				?>
																			</span>
																		</div>
																		<a href="#" class="sh-section__link sh-btn-icon"><i class="icon-Link"></i></a>
																	</div>
																	<div class="sh-section__content">
																		<p><?php echo $news["content"]; ?></p>
																	</div>
																	<div class="sh-section__footer">
																		<a href="#" class="sh-section__btn-comment sh-btn-icon"> 
																			<i class="fa fa-comment"></i>
																			<span> 34</span>
																		</a>
																		<a href="#" class="sh-section__btn-like sh-btn-icon"> 
																			<i class="fa fa-heart"></i>
																			<span> 1 274</span>
																		</a>
																	</div>
																</div>

																<?php		
																foreach ($list_news as $news2):
																	if($news2['type_page'] == "Commentaire"):
																		if($news['id'] == $news2['id_com']):
																			?>
																			<div class="sh-comments__section">
																				<a href="#" class="sh-comments__avatar sh-avatar">
																					<img src="<?php echo base_url()."assets/images/users/neymar.jpg"; ?>" alt="">
																				</a>
																				<div class="sh-comments__content">
																					<a href="#" class="sh-comments__name">DSVUI</a>
																					<span class="sh-comments__passed">. 
																						<?php
																						$datenews = date("d-m-Y", $news2["date"]);

																						if($datenews == $this->today):
																							echo "Aujourd'hui";
																						elseif($datenews == $this->yesterday):
																							echo "Hier";
																						elseif($datenews == $this->tommorow):
																							echo "Demain";
																						else:
																							echo date("d/m/Y", $news2["date"]);
																						endif;
																						echo date(" à h:i", $news2["date"]);
																						?>
																					</span>
																					<p><?php echo $news2["content"]; ?></p>
																					<div class="sh-comments__info">
																						<a href="#" class="sh-section__btn-like sh-btn-icon"> 
																							<i class="fa fa-heart"></i>
																							<span> 1 274</span>
																						</a>
																					</div>
																				</div>
																			</div>
																			<?php 
																		endif;
																	endif;
																endforeach;
																?>

																<div class="sh-add-comment">
																	<form action="#">
																		<input type="text" class="form-control ttg-border-none" placeholder="Add a Comment">
																	</form>
																	<div class="sh-add-comment__content">
																		<a href="#" class="sh-add-comment__btn-save sh-btn-icon"><span>180</span><i class="icon-Submit_Tick"></i></a>
																	</div>
																</div>
															</div>
															<?php
														endif;
														?>
														<?php
													endif;
												endforeach;
											endforeach;
											?>
										</div>
									</div>
								</div>
							</div>

							<div class="col-md-3">
								<table class="kode-table">
									<thead>
										<tr>
											<th>Ses matchs</th>
										</tr>
									</thead>
									<tbody>
										<?php foreach ($listGameTeam as $match): ?>
											<tr>
												<td>
													<a href="<?php echo base_url(). 'match/'. $match['id']; ?>">

														<?php echo $this->games_model->getAbbreviationTeam($match['id_home']).' '.$match['score_home'].' - '.$match['score_away'].' '.$this->games_model->getAbbreviationTeam($match['id_away']); ?></a>
													</td>
												</tr>
											<?php endforeach; ?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>
<!--// Main Content //-->