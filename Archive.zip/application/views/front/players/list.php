  <div class="kode-subheader subheader-height">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h1>players</h1>
        </div>
        <div class="col-md-6">
          <ul class="kode-breadcrumb">
            <li><a href="#">Home</a></li>
            <li><a href="#">Blog</a></li>
            <li><a href="#">Contact Us</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <!--// SubHeader //-->

  <!--// Main Content //-->
  <div class="kode-content">


    <!--// Page Content //-->
    <section class="kode-pagesection margin-bottom-40">
      <div class="container">
        <div class="row">

          <div class="col-md-12">                  
            <div class="heading heading-12 margin-top10-bottom30-flat">
              <p>Devoted to</p>
              <h2><span class="left"></span>OUR TEAM FORWARDS<span class="right"></span></h2>
            </div>
            <div class="kode-team-list">
              <ul class="row">
                <li class="col-md-4 col-sm-6">
                  <figure><a href="#" class="kode-team-thumb"><img src="https://www.psg.fr/img/image/upload/t_image_1080x1560,q_auto/gspaj7f1xm1kgcf3hsbo" alt=""></a>
                    <figcaption>
                      <ul class="kode-team-network">
                        <li><a href="#" class="fa fa-facebook"></a></li>
                        <li><a href="#" class="fa fa-twitter"></a></li>
                        <li><a href="#" class="fa fa-linkedin"></a></li>
                      </ul>
                      <div class="clearfix"></div>
                      <h2><a href="#">Kylian Mbappé</a></h2>
                      <a href="#" class="kode-modren-btn thbg-colortwo">Vew Detail</a>
                    </figcaption>
                  </figure>
                </li>
                <li class="col-md-4 col-sm-6">
                  <figure><a href="#" class="kode-team-thumb"><img src="https://www.psg.fr/img/image/upload/t_image_1080x1560,q_auto/vusnddgbmylese75uuhw" alt=""></a>
                    <figcaption>
                      <ul class="kode-team-network">
                        <li><a href="#" class="fa fa-facebook"></a></li>
                        <li><a href="#" class="fa fa-twitter"></a></li>
                        <li><a href="#" class="fa fa-linkedin"></a></li>
                      </ul>
                      <div class="clearfix"></div>
                      <h2><a href="#">Neymar Jr</a></h2>
                      <a href="#" class="kode-modren-btn thbg-colortwo">Vew Detail</a>
                    </figcaption>
                  </figure>
                </li>
                <li class="col-md-4 col-sm-6">
                  <figure><a href="#" class="kode-team-thumb"><img src="https://www.psg.fr/img/image/upload/t_image_1080x1560,q_auto/xif4y9nqobamfglvtsba" alt=""></a>
                    <figcaption>
                      <ul class="kode-team-network">
                        <li><a href="#" class="fa fa-facebook"></a></li>
                        <li><a href="#" class="fa fa-twitter"></a></li>
                        <li><a href="#" class="fa fa-linkedin"></a></li>
                      </ul>
                      <div class="clearfix"></div>
                      <h2><a href="#">Edinson Cavani</a></h2>
                      <a href="#" class="kode-modren-btn thbg-colortwo">Vew Detail</a>
                    </figcaption>
                  </figure>
                </li>
              </ul>
            </div>
          </div>






          <div class="col-md-12">                  
            <div class="heading heading-12 margin-top10-bottom30-flat">
              <p>Devoted to</p>
              <h2><span class="left"></span>OUR TEAM MIDFIELDERS<span class="right"></span></h2>
            </div>
            <div class="kode-team-list kode-team-modern">
              <ul class="row">
                <li class="col-md-4 col-sm-6">
                  <figure><a href="#" class="kode-team-thumb"><img src="https://www.psg.fr/img/image/upload/t_image_1080x1560,q_auto/gspaj7f1xm1kgcf3hsbo" alt=""></a>
                    <figcaption>
                      <ul class="kode-team-network">
                        <li><a href="#" class="fa fa-facebook"></a></li>
                        <li><a href="#" class="fa fa-twitter"></a></li>
                        <li><a href="#" class="fa fa-linkedin"></a></li>
                      </ul>
                      <div class="clearfix"></div>
                      <h2><a href="#">Kylian Mbappé</a></h2>
                      <a href="#" class="kode-modren-btn thbg-colortwo">Vew Detail</a>
                    </figcaption>
                  </figure>
                </li>
                <li class="col-md-4 col-sm-6">
                  <figure><a href="#" class="kode-team-thumb"><img src="https://www.psg.fr/img/image/upload/t_image_1080x1560,q_auto/vusnddgbmylese75uuhw" alt=""></a>
                    <figcaption>
                      <ul class="kode-team-network">
                        <li><a href="#" class="fa fa-facebook"></a></li>
                        <li><a href="#" class="fa fa-twitter"></a></li>
                        <li><a href="#" class="fa fa-linkedin"></a></li>
                      </ul>
                      <div class="clearfix"></div>
                      <h2><a href="#">Neymar Jr</a></h2>
                      <a href="#" class="kode-modren-btn thbg-colortwo">Vew Detail</a>
                    </figcaption>
                  </figure>
                </li>
                <li class="col-md-4 col-sm-6">
                  <figure><a href="#" class="kode-team-thumb"><img src="https://www.psg.fr/img/image/upload/t_image_1080x1560,q_auto/xif4y9nqobamfglvtsba" alt=""></a>
                    <figcaption>
                      <ul class="kode-team-network">
                        <li><a href="#" class="fa fa-facebook"></a></li>
                        <li><a href="#" class="fa fa-twitter"></a></li>
                        <li><a href="#" class="fa fa-linkedin"></a></li>
                      </ul>
                      <div class="clearfix"></div>
                      <h2><a href="#">Edinson Cavani</a></h2>
                      <a href="#" class="kode-modren-btn thbg-colortwo">Vew Detail</a>
                    </figcaption>
                  </figure>
                </li>
              </ul>
            </div>
          </div>

          <div class="col-md-12">                  
            <div class="heading heading-12 margin-top10-bottom30-flat">
              <p>Devoted to</p>
              <h2><span class="left"></span>OUR TEAM DEFENDERS<span class="right"></span></h2>
            </div>
            <div class="kode-team-list kode-team-modern">
              <ul class="row">
                <li class="col-md-3 col-sm-6">
                  <figure><a href="#" class="kode-team-thumb"><img src="https://www.psg.fr/img/image/upload/t_image_1080x1560,q_auto/gspaj7f1xm1kgcf3hsbo" alt=""></a>
                    <figcaption>
                      <ul class="kode-team-network">
                        <li><a href="#" class="fa fa-facebook"></a></li>
                        <li><a href="#" class="fa fa-twitter"></a></li>
                        <li><a href="#" class="fa fa-linkedin"></a></li>
                      </ul>
                      <div class="clearfix"></div>
                      <h2><a href="#">Kylian Mbappé</a></h2>
                    </figcaption>
                  </figure>
                </li>
                <li class="col-md-3 col-sm-6">
                  <figure><a href="#" class="kode-team-thumb"><img src="https://www.psg.fr/img/image/upload/t_image_1080x1560,q_auto/vusnddgbmylese75uuhw" alt=""></a>
                    <figcaption>
                      <ul class="kode-team-network">
                        <li><a href="#" class="fa fa-facebook"></a></li>
                        <li><a href="#" class="fa fa-twitter"></a></li>
                        <li><a href="#" class="fa fa-linkedin"></a></li>
                      </ul>
                      <div class="clearfix"></div>
                      <h2><a href="#">Neymar Jr</a></h2>                            
                    </figcaption>
                  </figure>
                </li>
                <li class="col-md-3 col-sm-6">
                  <figure><a href="#" class="kode-team-thumb"><img src="https://www.psg.fr/img/image/upload/t_image_1080x1560,q_auto/xif4y9nqobamfglvtsba" alt=""></a>
                    <figcaption>
                      <ul class="kode-team-network">
                        <li><a href="#" class="fa fa-facebook"></a></li>
                        <li><a href="#" class="fa fa-twitter"></a></li>
                        <li><a href="#" class="fa fa-linkedin"></a></li>
                      </ul>
                      <div class="clearfix"></div>
                      <h2><a href="#">Edinson Cavani</a></h2>                            
                    </figcaption>
                  </figure>
                </li>
                <li class="col-md-3 col-sm-6">
                  <figure><a href="#" class="kode-team-thumb"><img src="https://www.psg.fr/img/image/upload/t_image_1080x1560,q_auto/xif4y9nqobamfglvtsba" alt=""></a>
                    <figcaption>
                      <ul class="kode-team-network">
                        <li><a href="#" class="fa fa-facebook"></a></li>
                        <li><a href="#" class="fa fa-twitter"></a></li>
                        <li><a href="#" class="fa fa-linkedin"></a></li>
                      </ul>
                      <div class="clearfix"></div>
                      <h2><a href="#">Edinson Cavani</a></h2>                            
                    </figcaption>
                  </figure>
                </li>
              </ul>
            </div>
          </div>




          <div class="col-md-12">                  
            <div class="heading heading-12 margin-top10-bottom30-flat">
              <p>Devoted to</p>
              <h2><span class="left"></span>Goal Keeper<span class="right"></span></h2>
            </div>
            <div class="kode-team-list kode-team-modern">
              <ul class="row kode-align-center">
                <li class="col-md-5 col-sm-6">
                  <figure><a href="#" class="kode-team-thumb"><img src="https://www.psg.fr/img/image/upload/t_image_1080x1560,q_auto/gspaj7f1xm1kgcf3hsbo" alt=""></a>
                    <figcaption>
                      <ul class="kode-team-network">
                        <li><a href="#" class="fa fa-facebook"></a></li>
                        <li><a href="#" class="fa fa-twitter"></a></li>
                        <li><a href="#" class="fa fa-linkedin"></a></li>
                      </ul>
                      <div class="clearfix"></div>
                      <h2><a href="#">Kylian Mbappé</a></h2>
                      <a href="#" class="kode-modren-btn thbg-colortwo">Vew Detail</a>
                    </figcaption>
                  </figure>
                </li>
              </ul>
            </div>
          </div>

          <div class="col-md-12">                  
            <div class="heading heading-12 margin-top10-bottom30-flat">
              <p>Devoted to</p>
              <h2><span class="left"></span>OUR FACULTY STAFF<span class="right"></span></h2>
            </div>
            <div class="kode-team-list kode-team-modern kode-small">
              <ul class="row">
                <li class="col-md-2 col-sm-6">
                  <figure><a href="#" class="kode-team-thumb"><img src="https://www.psg.fr/img/image/upload/t_image_1080x1560,q_auto/gspaj7f1xm1kgcf3hsbo" alt=""></a>
                    <figcaption>
                      <ul class="kode-team-network">
                        <li><a href="#" class="fa fa-facebook"></a></li>
                        <li><a href="#" class="fa fa-twitter"></a></li>
                        <li><a href="#" class="fa fa-linkedin"></a></li>
                      </ul>
                      <div class="clearfix"></div>
                      <h2><a href="#">Kylian Mbappé</a></h2>
                      <a href="#" class="kode-modren-btn thbg-colortwo">Vew Detail</a>
                    </figcaption>
                  </figure>
                </li>
                <li class="col-md-2 col-sm-6">
                  <figure><a href="#" class="kode-team-thumb"><img src="https://www.psg.fr/img/image/upload/t_image_1080x1560,q_auto/vusnddgbmylese75uuhw" alt=""></a>
                    <figcaption>
                      <ul class="kode-team-network">
                        <li><a href="#" class="fa fa-facebook"></a></li>
                        <li><a href="#" class="fa fa-twitter"></a></li>
                        <li><a href="#" class="fa fa-linkedin"></a></li>
                      </ul>
                      <div class="clearfix"></div>
                      <h2><a href="#">Neymar Jr</a></h2>
                      <a href="#" class="kode-modren-btn thbg-colortwo">Vew Detail</a>
                    </figcaption>
                  </figure>
                </li>
                <li class="col-md-2 col-sm-6">
                  <figure><a href="#" class="kode-team-thumb"><img src="https://www.psg.fr/img/image/upload/t_image_1080x1560,q_auto/xif4y9nqobamfglvtsba" alt=""></a>
                    <figcaption>
                      <ul class="kode-team-network">
                        <li><a href="#" class="fa fa-facebook"></a></li>
                        <li><a href="#" class="fa fa-twitter"></a></li>
                        <li><a href="#" class="fa fa-linkedin"></a></li>
                      </ul>
                      <div class="clearfix"></div>
                      <h2><a href="#">Edinson Cavani</a></h2>
                      <a href="#" class="kode-modren-btn thbg-colortwo">Vew Detail</a>
                    </figcaption>
                  </figure>
                </li>
                <li class="col-md-2 col-sm-6">
                  <figure><a href="#" class="kode-team-thumb"><img src="https://www.psg.fr/img/image/upload/t_image_1080x1560,q_auto/gspaj7f1xm1kgcf3hsbo" alt=""></a>
                    <figcaption>
                      <ul class="kode-team-network">
                        <li><a href="#" class="fa fa-facebook"></a></li>
                        <li><a href="#" class="fa fa-twitter"></a></li>
                        <li><a href="#" class="fa fa-linkedin"></a></li>
                      </ul>
                      <div class="clearfix"></div>
                      <h2><a href="#">Kylian Mbappé</a></h2>
                      <a href="#" class="kode-modren-btn thbg-colortwo">Vew Detail</a>
                    </figcaption>
                  </figure>
                </li>
                <li class="col-md-2 col-sm-6">
                  <figure><a href="#" class="kode-team-thumb"><img src="https://www.psg.fr/img/image/upload/t_image_1080x1560,q_auto/vusnddgbmylese75uuhw" alt=""></a>
                    <figcaption>
                      <ul class="kode-team-network">
                        <li><a href="#" class="fa fa-facebook"></a></li>
                        <li><a href="#" class="fa fa-twitter"></a></li>
                        <li><a href="#" class="fa fa-linkedin"></a></li>
                      </ul>
                      <div class="clearfix"></div>
                      <h2><a href="#">Neymar Jr</a></h2>
                      <a href="#" class="kode-modren-btn thbg-colortwo">Vew Detail</a>
                    </figcaption>
                  </figure>
                </li>
                <li class="col-md-2 col-sm-6">
                  <figure><a href="#" class="kode-team-thumb"><img src="https://www.psg.fr/img/image/upload/t_image_1080x1560,q_auto/xif4y9nqobamfglvtsba" alt=""></a>
                    <figcaption>
                      <ul class="kode-team-network">
                        <li><a href="#" class="fa fa-facebook"></a></li>
                        <li><a href="#" class="fa fa-twitter"></a></li>
                        <li><a href="#" class="fa fa-linkedin"></a></li>
                      </ul>
                      <div class="clearfix"></div>
                      <h2><a href="#">Edinson Cavani</a></h2>
                      <a href="#" class="kode-modren-btn thbg-colortwo">Vew Detail</a>
                    </figcaption>
                  </figure>
                </li>
              </ul>
            </div>
          </div>

        </div>
      </div>
    </section>
    <!--// Page Content //-->		

  </div>
  <!--// Main Content //-->