<div class="kode-subheader subheader-height">
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<h1>History</h1>
			</div>
			<div class="col-md-6">
				<ul class="kode-breadcrumb">
					<li><a href="#">Home</a></li>
					<li><a href="#">Blog</a></li>
					<li><a href="#">Contact Us</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
<!--// SubHeader //-->

<!--// Main Content //-->
<div class="kode-content">
	<!--// Page Content //-->
	<section class="kode-pagesection">
		<div class="container">
			<div class="row">
				<div class="kode-pagecontent col-md-12">
					<div class="kode-gallery">
						<ul class="row">
							<li class="col-md-4">
								<figure><a href="#"><img src="http://lmdpsg.com:8888/CodeIgniter/assets/images/news/newsdefault.jpg" alt=""></a>
									<figcaption><a href="#" class="kode-gallery-hover thbg-color"><i class="fa fa-plus"></i></a></figcaption>
								</figure>
								<div class="kode-gallery-info">
									<h2><a href="#">dignissimos ducimus</a></h2>
									<p>Lorem ipsum dolor</p>
								</div>
							</li>
							<li class="col-md-4">
								<figure><a href="#"><img src="http://lmdpsg.com:8888/CodeIgniter/assets/images/news/newsdefault.jpg" alt=""></a>
									<figcaption><a href="#" class="kode-gallery-hover thbg-color"><i class="fa fa-plus"></i></a></figcaption>
								</figure>
								<div class="kode-gallery-info">
									<h2><a href="#">dignissimos ducimus</a></h2>
									<p>Lorem ipsum dolor</p>
								</div>
							</li>
							<li class="col-md-4">
								<figure><a href="#"><img src="http://lmdpsg.com:8888/CodeIgniter/assets/images/news/newsdefault.jpg" alt=""></a>
									<figcaption><a href="#" class="kode-gallery-hover thbg-color"><i class="fa fa-plus"></i></a></figcaption>
								</figure>
								<div class="kode-gallery-info">
									<h2><a href="#">dignissimos ducimus</a></h2>
									<p>Lorem ipsum dolor</p>
								</div>
							</li>
							<li class="col-md-4">
								<figure><a href="#"><img src="http://lmdpsg.com:8888/CodeIgniter/assets/images/news/newsdefault.jpg" alt=""></a>
									<figcaption><a href="#" class="kode-gallery-hover thbg-color"><i class="fa fa-plus"></i></a></figcaption>
								</figure>
								<div class="kode-gallery-info">
									<h2><a href="#">dignissimos ducimus</a></h2>
									<p>Lorem ipsum dolor</p>
								</div>
							</li>
						<li class="col-md-4">
								<figure><a href="#"><img src="http://lmdpsg.com:8888/CodeIgniter/assets/images/news/newsdefault.jpg" alt=""></a>
									<figcaption><a href="#" class="kode-gallery-hover thbg-color"><i class="fa fa-plus"></i></a></figcaption>
								</figure>
								<div class="kode-gallery-info">
									<h2><a href="#">dignissimos ducimus</a></h2>
									<p>Lorem ipsum dolor</p>
								</div>
							</li>
						<li class="col-md-4">
								<figure><a href="#"><img src="http://lmdpsg.com:8888/CodeIgniter/assets/images/news/newsdefault.jpg" alt=""></a>
									<figcaption><a href="#" class="kode-gallery-hover thbg-color"><i class="fa fa-plus"></i></a></figcaption>
								</figure>
								<div class="kode-gallery-info">
									<h2><a href="#">dignissimos ducimus</a></h2>
									<p>Lorem ipsum dolor</p>
								</div>
							</li>
						</ul>
						<!--// Pagination //-->
						<div class="pagination">
							<a href="#"><i class="fa fa-angle-double-left"></i></a>
							<a href="#">1</a>
							<a href="#">2</a>
							<span>3</span>
							<a href="#">4</a>
							<a href="#"><i class="fa fa-angle-double-right"></i></a>
						</div>
						<!--// Pagination //-->
					</div>

				</div>

			</div>
		</div>
	</section>
	<!--// Page Content //-->

</div>
<!--// Main Content //-->