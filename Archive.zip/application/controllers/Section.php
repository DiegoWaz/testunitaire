<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Section extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct() {
		
		parent::__construct();
		$this->load->library(array('session'));
		$this->load->helper(array('url'));
		$this->load->model('user_model');
		$this->load->model('news_model');
		$this->load->model('conf_model');
		$this->load->model('games_model');
		$this->load->helper('url');

		$title = $this->conf_model->get_conf("site_name");
		$description = $this->conf_model->get_conf("site_desc");

		$this->title = $title[0]["value"];
		$this->description = $description[0]["value"];

		$this->output->set_template('front');
		$this->lastNews = $this->news_model->get_list_news(3);
	}

	
}
