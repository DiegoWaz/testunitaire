<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct() {
		
		parent::__construct();
		$this->load->library(array('session'));
		$this->load->helper(array('url'));
		$this->load->model('user_model');
		$this->load->model('news_model');
		$this->load->model('conf_model');
		$this->load->model('games_model');
		$this->load->helper('url');

		$title = $this->conf_model->get_conf("site_name");
		$description = $this->conf_model->get_conf("site_desc");
		$this->section = $this->conf_model->get_section();

		$this->title = $title[0]["value"];
		$this->description = $description[0]["value"];

		$this->lastNews = $this->news_model->get_list_news(3);
	}

	public function index($id)
	{
		$this->title = 'Le Meilleur du PSG - Rédiger un article';
		$this->description = "Le back-office du site Le Meilleur du PSG";
		$this->type = "edit";

		$data["id"] = $id;

		$data['link'] = base_url()."assets/back/";

		$data["type"] = $this->type;
		$idcomment = $this->input->post("id_comment");
		$idpseudo = $this->input->post("id_pseudo");

		$data["classSelect"] = array(
	        'class'   		=> 'form-control'
		);

		$data["news"] = $this->news_model->get_news_id($id);

		$data['rubrique'] = $this->news_model->get_listRubrique();
		$data['section'] = $this->news_model->get_listSection();
		$data['matchs'] = $this->games_model->listGame(1);
		$data['clubs'] = $this->games_model->getListClubs();
		$data['players'] = $this->games_model->getListPlayers();
        $data['postPlayers'] = $this->news_model->getPostPlayer($id);
        $data['postTeams'] = $this->news_model->getPostTeam($id);
        $data['postMatchs'] = $this->news_model->getPostMatch($id);


		$data['tops'] = $this->news_model->getListTop();

        foreach ($data['postPlayers'] as $value) {
            $data['postPlayer'] = explode(',', $value['id_player']);
        }        

        foreach ($data['postTeams'] as $value) {
            $data['postTeam'] = explode(',', $value['id_team']);
        }

        foreach ($data['postMatchs'] as $value) {
            $data['postMatch'] = explode(',', $value['id_match']);
        }

		if(isset($idcomment)) {
			$data["update"] = $this->news_model->updateValid($idcomment, $idpseudo, 1);
		}

		$data["idcomment"] = $this->input->post("id_comment");

		$this->load->view('back/test', $data);
	}
}
