<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Upload extends CI_Controller {

    public function __construct()
    {
            parent::__construct();
            $this->load->helper(array('form', 'url'));
    }

    public function index()
    {
            $this->load->view('back/upload_form', array('error' => ' ' ));
    }

    public function do_upload()
    {
        $config['upload_path']          = 'assets/images/news/';
        $config['allowed_types']        = 'gif|jpg|png';
        $config['max_size']             = 2000;
        $config['image_width']          = 969;
        $config['image_height']         = 650;

        $this->load->library('upload', $config);

        if ( ! $this->upload->do_upload('userfile')) {

                $error = array('error' => $this->upload->display_errors());

                $this->load->view('back/upload_form', $error);
        }
        else {
                $data = array('upload_data' => $this->upload->data());

                $this->load->view('back/upload_success', $data);
        }
    }

    public function resize() {

        $config['image_library'] = 'gd2';
        $config['source_image'] = '/path/to/image/mypic.jpg';
        $config['create_thumb'] = TRUE;
        $config['maintain_ratio'] = TRUE;
        $config['width']         = 75;
        $config['height']       = 50;

        $this->load->library('image_lib', $config);

        $this->image_lib->resize();

        if ( ! $this->image_lib->resize()) {
            echo $this->image_lib->display_errors();
        }
    }
}
?>