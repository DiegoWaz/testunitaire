<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Back extends CI_Controller {

	public function __construct() {
		
		parent::__construct();
		$this->load->library(array('session'));
		$this->load->helper(array('url'));
		$this->load->helper('form');
		$this->load->model('user_model');
		$this->load->model('news_model');
		$this->load->model('games_model');
		$this->load->helper('url');
		$this->load->helper('date');
		$this->load->helper(array("url", "text"));
		$this->output->set_template('back');
		$this->dependenciesCSS = array(
			'plugins/font-awesome/css/font-awesome.css',
			'plugins/bootstrap-tag/bootstrap-tagsinput.css',
			'plugins/dropzone/css/dropzone.css',
			'plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.css',
			'plugins/bootstrap-datepicker/css/datepicker.css',
			'plugins/bootstrap-timepicker/css/bootstrap-timepicker.css',
			'plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.css',
			'plugins/ios-switch/ios7-switch.css',
			'plugins/bootstrap-select2/select2.css',
			'plugins/boostrap-clockpicker/bootstrap-clockpicker.min.css',
			'plugins/ios-switch/ios7-switch.css',
			'webarch/css/webarch.css'
		);

		$this->dependenciesJS = array(
			'plugins/pace/pace.min.js',
			'plugins/jquery/jquery-1.11.3.min.js',
			'plugins/bootstrapv3/js/bootstrap.min.js',
			'plugins/jquery-block-ui/jqueryblockui.min.js',
			'plugins/jquery-unveil/jquery.unveil.min.js',
			'plugins/jquery-scrollbar/jquery.scrollbar.min.js',
			'plugins/jquery-numberAnimate/jquery.animateNumbers.js',
			'plugins/jquery-validation/js/jquery.validate.min.js',
			'plugins/bootstrap-select2/select2.min.js',
			'webarch/js/webarch.js',
			'js/chat.js',
			'js/script.js'
		);
	    $this->today = date("d-m-Y", time());
        $this->yesterday = date('d-m-Y', time() - 3600 * 24);
        $this->tommorow = date('d-m-Y', time() + 3600 * 24);
        
        $today = $this->today;
        $yesterday = $this->yesterday;
        $tommorow = $this->tommorow;
	}

	public function index()
	{

		$this->title = 'Le Meilleur du PSG - Todo List';
		$this->description = "Le back-office du site Le Meilleur du PSG";

		$data['dependenciesCSS'] = $this->dependenciesCSS;
		$data['dependenciesJS'] = $this->dependenciesJS;

		$data['requireCSS'] = $this->requireCSS = array(
			'plugins/jquery-slider/css/jquery.sidr.light.css',
			'plugins/jquery-ricksaw-chart/css/rickshaw.css',
			'plugins/Mapplic/mapplic/mapplic.css',
			'plugins/pace/pace-theme-flash.css',
			'plugins/bootstrapv3/css/bootstrap.min.css',
			'plugins/bootstrapv3/css/bootstrap-theme.min.css',
			'plugins/animate.min.css',
			'plugins/jquery-scrollbar/jquery.scrollbar.css',
			'plugins/ios-switch/ios7-switch.css',
			'webarch/css/webarch.css'
		);

		$data['requirejs'] = $this->requirejs = array(
			'js/support_ticket.js'
		);

		$data["list_news"] = $this->news_model->get_list_news(10);

		$data["title"] = $this->form = array(
		        'name'          => 'title',
		        'id'            => 'title',
		        'placeholder'   => 'Titre',
		        'class'   		=> 'form-control',
		);			

		$data["link"] = $this->form = array(
		        'name'          => 'link',
		        'id'            => 'link',
		        'placeholder'   => 'http://',
		        'class'   		=> 'form-control',
		        'required'   	=> 'required',
		);		

		$data["comment"] = $this->form = array(
		        'name'          => 'comment',
		        'id'            => 'comment',
		        'placeholder'   => 'Ajoute un commentaire',
		        'class'   		=> 'form-control',
		        'row'			=> '8'
		);		

		$data["replyComments"] = $this->form = array(
		        'name'          => 'replycomment',
		        'id'            => 'replycomment',
		        'placeholder'   => 'Répondre au commentaire',
		        'class'   		=> 'form-control'
		);

		$data["oui"] = $this->form = array(
		        'name'          => 'important',
		        'id'            => 'important',
		        'class'   		=> 'ios',
		        'value'   		=> '1',
		);		

		$data["non"] = $this->form = array(
		        'name'          => 'important',
		        'id'            => 'important',
		        'class'   		=> 'ios',
		        'value'   		=> '0',
		);

		$data['status'] = $this->status = array(
		    'wip',
		    'todo',
		    'close'
		);

		// A faire
		$data["todo"] = $this->news_model->get_todolist(0, 20);

		// Work In Progress | En cours
		$data["wip"] = $this->news_model->get_todolist(1, 20);

		// Fini
		$data["close"] = $this->news_model->get_todolist(2, 20);

		$this->load->view('back/index', $data);
	}

	public function listNews()
	{

		$this->title = 'Le Meilleur du PSG - Liste des articles';
		$this->description = "Le site le plus complet sur l'actualité du Paris Saint-Germain. Pour tout savoir sur les résultats, l'équipe, les transferts, les joueurs, les matchs, les supporters, etc...";

		$data['dependenciesCSS'] = $this->dependenciesCSS;
		$data['dependenciesJS'] = $this->dependenciesJS;

		$data['requireCSS'] = $this->requireCSS = array(
			'plugins/jquery-slider/css/jquery.sidr.light.css',
			'plugins/jquery-ricksaw-chart/css/rickshaw.css',
			'plugins/Mapplic/mapplic/mapplic.css',
			'plugins/pace/pace-theme-flash.css',
			'plugins/bootstrapv3/css/bootstrap.min.css',
			'plugins/bootstrapv3/css/bootstrap-theme.min.css',
			'plugins/animate.min.css',
			'plugins/jquery-scrollbar/jquery.scrollbar.css',
			'plugins/ios-switch/ios7-switch.css',
			'webarch/css/webarch.css'
		);

		$data['requirejs'] = $this->requirejs = array(
			'js/support_ticket.js'
		);

		$data["list_news"] = $this->news_model->get_list_news(0);
		$data["list_sections"] = $this->news_model->get_ListSection();
		$data["list"] = $this->news_model->get_ListRubrique();
		
		$this->load->view('back/listnews', $data);
	}

	public function rubriqueList()
	{

		$this->title = 'Le Meilleur du PSG - Todo List';
		$this->description = "Le back-office du site Le Meilleur du PSG";

		$data['dependenciesCSS'] = $this->dependenciesCSS;
		$data['dependenciesJS'] = $this->dependenciesJS;

		$data['requireCSS'] = $this->requireCSS = array(
			'plugins/jquery-slider/css/jquery.sidr.light.css',
			'plugins/jquery-ricksaw-chart/css/rickshaw.css',
			'plugins/Mapplic/mapplic/mapplic.css',
			'plugins/pace/pace-theme-flash.css',
			'plugins/bootstrapv3/css/bootstrap.min.css',
			'plugins/bootstrapv3/css/bootstrap-theme.min.css',
			'plugins/animate.min.css',
			'plugins/jquery-scrollbar/jquery.scrollbar.css',
			'plugins/ios-switch/ios7-switch.css',
			'webarch/css/webarch.css'
		);

		$data['requirejs'] = $this->requirejs = array(
			'js/support_ticket.js'
		);

		$data["list_news"] = $this->news_model->get_list_news(10);
		$data["list_section"] = $this->news_model->get_ListSection();

		$data["title"] = $this->form = array(
		        'name'          => 'title',
		        'id'            => 'title',
		        'placeholder'   => 'Titre',
		        'class'   		=> 'form-control',
		);		

		$data["type"] = "rubrique";
		$data["action"] = "add";
		$data["list"] = $this->news_model->get_ListRubrique();

		$this->load->view('back/list', $data);
	}		

	public function mercatoList()
	{

		$this->title = 'Le Meilleur du PSG - Todo List';
		$this->description = "Le back-office du site Le Meilleur du PSG";

		$data['dependenciesCSS'] = $this->dependenciesCSS;
		$data['dependenciesJS'] = $this->dependenciesJS;

		$data['requireCSS'] = $this->requireCSS = array(
			'plugins/jquery-slider/css/jquery.sidr.light.css',
			'plugins/jquery-ricksaw-chart/css/rickshaw.css',
			'plugins/Mapplic/mapplic/mapplic.css',
			'plugins/pace/pace-theme-flash.css',
			'plugins/bootstrapv3/css/bootstrap.min.css',
			'plugins/bootstrapv3/css/bootstrap-theme.min.css',
			'plugins/animate.min.css',
			'plugins/jquery-scrollbar/jquery.scrollbar.css',
			'plugins/ios-switch/ios7-switch.css',
			'webarch/css/webarch.css'
		);

		$data['requirejs'] = $this->requirejs = array(
			'js/support_ticket.js'
		);

		$data["title"] = $this->form = array(
		        'name'          => 'title',
		        'id'            => 'title',
		        'placeholder'   => 'Titre',
		        'class'   		=> 'form-control',
		);		

		$data["type"] = "rubrique";
		$data["action"] = "add";
		$data["list"] = $this->news_model->get_ListRubrique();
		$data["list_sections"] = $this->news_model->get_ListSection();
		$data["list"] = $this->news_model->get_ListRubrique();

		$this->load->view('back/list', $data);
	}	

	public function rubrique($id)
	{

		$this->title = 'Le Meilleur du PSG - Todo List';
		$this->description = "Le back-office du site Le Meilleur du PSG";

		$data['dependenciesCSS'] = $this->dependenciesCSS;
		$data['dependenciesJS'] = $this->dependenciesJS;

		$data['requireCSS'] = $this->requireCSS = array(
			'plugins/jquery-slider/css/jquery.sidr.light.css',
			'plugins/jquery-ricksaw-chart/css/rickshaw.css',
			'plugins/Mapplic/mapplic/mapplic.css',
			'plugins/pace/pace-theme-flash.css',
			'plugins/bootstrapv3/css/bootstrap.min.css',
			'plugins/bootstrapv3/css/bootstrap-theme.min.css',
			'plugins/animate.min.css',
			'plugins/jquery-scrollbar/jquery.scrollbar.css',
			'plugins/ios-switch/ios7-switch.css',
			'webarch/css/webarch.css'
		);

		$data['requirejs'] = $this->requirejs = array(
			'js/support_ticket.js'
		);

		$data["title"] = $this->form = array(
		        'name'          => 'title',
		        'id'            => 'title',
		        'placeholder'   => 'Titre',
		        'class'   		=> 'form-control',
		);		

		$data["type"] = "rubrique";
		$data["action"] = "add";

		$data["list_sections"] = $this->news_model->get_ListSection();
		$data["list"] = $this->news_model->get_ListRubrique();

		$data["list_news"] = $this->news_model->get_oneRubrique($id, 0);

		$this->load->view('back/listnews', $data);
	}	

	public function sectionList()
	{

		$this->title = 'Le Meilleur du PSG - Todo List';
		$this->description = "Le back-office du site Le Meilleur du PSG";

		$data['dependenciesCSS'] = $this->dependenciesCSS;
		$data['dependenciesJS'] = $this->dependenciesJS;

		$data['requireCSS'] = $this->requireCSS = array(
			'plugins/jquery-slider/css/jquery.sidr.light.css',
			'plugins/jquery-ricksaw-chart/css/rickshaw.css',
			'plugins/Mapplic/mapplic/mapplic.css',
			'plugins/pace/pace-theme-flash.css',
			'plugins/bootstrapv3/css/bootstrap.min.css',
			'plugins/bootstrapv3/css/bootstrap-theme.min.css',
			'plugins/animate.min.css',
			'plugins/jquery-scrollbar/jquery.scrollbar.css',
			'plugins/ios-switch/ios7-switch.css',
			'webarch/css/webarch.css'
		);

		$data['requirejs'] = $this->requirejs = array(
			'js/support_ticket.js'
		);

		$data["list_news"] = $this->news_model->get_list_news(10);

		$data["title"] = $this->form = array(
		        'name'          => 'title',
		        'id'            => 'title',
		        'placeholder'   => 'Titre',
		        'class'   		=> 'form-control',
		);		

		$data["type"] = "section";
		$data["action"] = "add";
		$data["list"] = $this->news_model->get_ListSection();

		$this->load->view('back/list', $data);
	}

	public function section($id)
	{

		$this->title = 'Le Meilleur du PSG - Todo List';
		$this->description = "Le back-office du site Le Meilleur du PSG";

		$data['dependenciesCSS'] = $this->dependenciesCSS;
		$data['dependenciesJS'] = $this->dependenciesJS;

		$data['requireCSS'] = $this->requireCSS = array(
			'plugins/jquery-slider/css/jquery.sidr.light.css',
			'plugins/jquery-ricksaw-chart/css/rickshaw.css',
			'plugins/Mapplic/mapplic/mapplic.css',
			'plugins/pace/pace-theme-flash.css',
			'plugins/bootstrapv3/css/bootstrap.min.css',
			'plugins/bootstrapv3/css/bootstrap-theme.min.css',
			'plugins/animate.min.css',
			'plugins/jquery-scrollbar/jquery.scrollbar.css',
			'plugins/ios-switch/ios7-switch.css',
			'webarch/css/webarch.css'
		);

		$data['requirejs'] = $this->requirejs = array(
			'js/support_ticket.js'
		);

		$data["list_news"] = $this->news_model->get_list_news_section($id, 0);
		$data["list"] = $this->news_model->get_ListSection();

		$data["title"] = $this->form = array(
		        'name'          => 'title',
		        'id'            => 'title',
		        'placeholder'   => 'Titre',
		        'class'   		=> 'form-control',
		);		

		$data["list_sections"] = $this->news_model->get_ListSection();
		$data["list"] = $this->news_model->get_ListRubrique();

		$data["type"] = "section";
		$data["action"] = "add";

		$this->load->view('back/listnews', $data);
	}

	public function editSection($slug)
	{

		$this->title = 'Le Meilleur du PSG - Section';
		$this->description = "Le back-office du site Le Meilleur du PSG";

		$data['dependenciesCSS'] = $this->dependenciesCSS;
		$data['dependenciesJS'] = $this->dependenciesJS;

		$data['requireCSS'] = $this->requireCSS = array(
			'plugins/jquery-slider/css/jquery.sidr.light.css',
			'plugins/jquery-ricksaw-chart/css/rickshaw.css',
			'plugins/Mapplic/mapplic/mapplic.css',
			'plugins/pace/pace-theme-flash.css',
			'plugins/bootstrapv3/css/bootstrap.min.css',
			'plugins/bootstrapv3/css/bootstrap-theme.min.css',
			'plugins/animate.min.css',
			'plugins/jquery-scrollbar/jquery.scrollbar.css',
			'plugins/ios-switch/ios7-switch.css',
			'webarch/css/webarch.css'
		);

		$data['requirejs'] = $this->requirejs = array(
			'js/support_ticket.js'
		);

		$data["list_news"] = $this->news_model->get_list_news_section($slug, 0);
		$data["list"] = $this->news_model->get_ListSection();
		$data["section"] = $this->news_model->get_section($slug);

		foreach ($data["section"] as $value) {
			$id = $value["id"];
			$section = $value["name"];
		}

		$data["title"] = $this->form = array(
		        'name'          => 'title',
		        'id'            => 'title',
		        'placeholder'   => 'Titre',
		        'class'   		=> 'form-control',
		        'value'			=>  $section,
		);

		$data["id"] = $id;

		$data["type"] = "section";
		$data["action"] = "edit";
		$this->slug = $slug;

		$this->load->view('back/list', $data);
	}

	public function editRubrique($id)
	{

		$this->title = 'Le Meilleur du PSG - Section';
		$this->description = "Le back-office du site Le Meilleur du PSG";

		$data['dependenciesCSS'] = $this->dependenciesCSS;
		$data['dependenciesJS'] = $this->dependenciesJS;

		$data['requireCSS'] = $this->requireCSS = array(
			'plugins/jquery-slider/css/jquery.sidr.light.css',
			'plugins/jquery-ricksaw-chart/css/rickshaw.css',
			'plugins/Mapplic/mapplic/mapplic.css',
			'plugins/pace/pace-theme-flash.css',
			'plugins/bootstrapv3/css/bootstrap.min.css',
			'plugins/bootstrapv3/css/bootstrap-theme.min.css',
			'plugins/animate.min.css',
			'plugins/jquery-scrollbar/jquery.scrollbar.css',
			'plugins/ios-switch/ios7-switch.css',
			'webarch/css/webarch.css'
		);

		$data['requirejs'] = $this->requirejs = array(
			'js/support_ticket.js'
		);

		$data["list_news"] = $this->news_model->get_list_news(0);
		$data["list"] = $this->news_model->get_ListRubrique();

		$data["rubrique"] = $this->news_model->get_oneRubrique($id);

		foreach ($data["rubrique"] as $value) {
			$id = $value["id"];
			$rubrique = $value["name"];
			$slug = $value["slug"];
		}

		$data["title"] = $this->form = array(
		        'name'          => 'title',
		        'id'            => 'title',
		        'placeholder'   => 'Titre',
		        'class'   		=> 'form-control',
		        'value'			=>  $rubrique,
		);

		$data["id"] = $id;

		$data["type"] = "rubrique";
		$data["action"] = "edit";
		$this->slug = $slug;

		$this->load->view('back/list', $data);
	}

	public function formValidTodoList()
	{

		$title = $this->input->post("title");
		$link = $this->input->post("link");
		$comment = $this->input->post("comment");
		$idPseudo = $this->input->post("id_pseudo");
		$important = $this->input->post("important");

		$data["insert"] = $this->news_model->addTodoListNews($idPseudo, $title, 0, $link, $comment, $important);

		$this->load->view('back/formValid', $data);

	}		

	public function formValidaddNews()
	{
        $this->load->helper(array("url", "text"));

		$this->load->library('form_validation');
		
		// set validation rules
		$this->form_validation->set_rules('title', 'Titre', 'is_unique[posts.title]', array('is_unique' => 'Le titre est déjà existant. Trouve un autre nom'));

		$title = $this->input->post("title");
		$resume = $this->input->post("resume");		
		$rubrique = $this->input->post("rubrique");
		$section = $this->input->post("section");
		$content = $this->input->post("content");
		$status = $this->input->post("status");
		$players = $this->input->post("players");
		$games = $this->input->post("games");
		$teams = $this->input->post("teams");
		$day = $this->input->post("date");
		$hour = $this->input->post("time");
		$author = $this->input->post("users");
        $date = strtotime($day.$hour);
		$todolist = $this->input->post("todolist");
		$story = $this->input->post("story");
		$idPseudo = 2;
		$important = 1;
		$image = "newsdefault.jpg";
		$slug = convert_accented_characters(url_title($title));
		$type = "Article";
		$id = $this->input->post("idcomment");
		$st = 2;

        // Feuilleton mercato
        $idplayer = $this->input->post("player");
        $club = $this->games_model->player($idplayer);
        $idteam1 = $club->clubactuel;
        $idteam2 = $this->input->post("team2");
        $contract = $this->input->post("contract");

        if(isset($games)){
			$game = implode(', ', $games);
		} else {
			$game = false;
		}
		
		//$this->upload->do_upload($field_name);

		if(isset($players)){
			$player = implode(', ', $players);
		} else {
			$player = false;
		}

		if(isset($teams)){
			$team = implode(', ', $teams);
		} else {
			$team = false;
		}

		if(isset($authors)){
			$author = implode(', ', $authors);
		} else {
			$author = false;
		}


        $data["insert"] = $this->news_model->addNews($title, $image, $resume, $rubrique, $section, $content, $status, $important, $type, $slug, $player, $game, $story, $team, $date, $author, $idplayer, $idteam1, $idteam2, $contract);
		$data["changestatus"] = $this->news_model->updateValid($id, $idPseudo, $st);

        $this->session->set_flashdata('success', "L'article a bien été ajouté");
		$this->load->view('back/formNews', $data);

	}		

	public function formValideditNews()
	{
		$post = $_POST;

        $this->load->helper(array("url", "text"));

        foreach ($post as $key => $value) {
        	${$key} = $value;
        }

		if(!isset($image)){
			$image = "newsdefault.jpg";
		}

        $date = $date = strtotime($date.$time);

		$slug = convert_accented_characters(url_title($title)).'-'.$id;
		$st = 2;

        // Feuilleton mercato

        if(!empty($id_player)){
			$club = $this->games_model->player($id_player);
        	$id_team = $club->clubactuel;
		} else {
			$id_player = 0;
			$id_team = 0;
		}

		if(isset($une)): 
			$une = 1;
		else: 
			$une = 0;
		endif;

		if(isset($id_players)){
			$id_players = implode(', ', $id_players);
		} else {
			$id_players = 0;
		}

		if(isset($id_matchs)){
			$id_matchs = implode(', ', $id_matchs);
		} else {
			$id_matchs = 0;
		}

		if(isset($id_teams)){
			$id_teams = implode(', ', $id_teams);
		} else {
			$id_teams = 0;
		}
		
		if(isset($author_id)){
			$author_id = implode(', ', $author_id);
		} else {
			$author_id = 0;
		}
		
		if(!isset($story)):
			$story = 0;
		endif;



        $data['postMercato'] = $this->news_model->getPostMercato($id);
		$data["changestatus"] = $this->news_model->updateValid($idcomment, $author_id, $st);

        if(!empty($data['postMercato'])):
        	$data["update"] = $this->news_model->editNews($id, $title, $image, $status, $resume, $rubrique, $content, $section, $type_page, $slug, $une, $story, $id_players, $id_matchs, $id_teams, $date, $author_id);
            $data["mercato"] = $this->news_model->editMercato($id, $type_contract, $id_player, $id_team, $id_team2);

        else:
			$data["update"] = $this->news_model->addMercatoEditNews($id, $title, $image, $resume, $rubrique, $section, $content, $status, $une, $type_page, $slug, $id_players, $id_matchs, $id_teams, $story, $id_team, $date, $author_id, $id_player, $id_team, $id_team2, $type_contract);
        endif;

        $this->session->set_flashdata('success', "L'article a bien été edité");

        $this->load->view('back/formValid', $data);
	}	

	public function formValidReplyTodoList()
	{

		$idcomment = $this->input->post("id_comment");
		$comment = $this->input->post("replycomment");
		$idPseudo = $this->input->post("id_pseudo");

		$data["insert"] = $this->news_model->addReplyTodoListNews($idPseudo, $comment, $idcomment);

		$this->load->view('back/formValid', $data);
	}

	public function news()
	{

		$this->title = 'Le Meilleur du PSG - Rédiger un article';
		$this->description = "Le back-office du site Le Meilleur du PSG";
		$this->type = "add";
		$data["type"] = $this->type;

		$this->type2 = "Ajouter";
		$data["type2"] = $this->type2;

		$data['dependenciesCSS'] = $this->dependenciesCSS;
		$data['dependenciesJS'] = $this->dependenciesJS;

		$data['requireCSS'] = $this->requireCSS = array(
			'plugins/pace/pace-theme-flash.css',
			'plugins/bootstrapv3/css/bootstrap.min.css',
			'plugins/bootstrapv3/css/bootstrap-theme.min.css',
			'plugins/animate.min.css',
			'plugins/jquery-scrollbar/jquery.scrollbar.css',
			'webarch/css/webarch.css'
		);

		$data['requirejs'] = $this->requirejs = array(
			'plugins/bootstrap-datepicker/js/bootstrap-datepicker.js',
			'plugins/bootstrap-timepicker/js/bootstrap-timepicker.min.js',
			'plugins/jquery-inputmask/jquery.inputmask.min.js',
			'plugins/jquery-autonumeric/autoNumeric.js',
			'plugins/ios-switch/ios7-switch.js',
			'plugins/bootstrap-select2/select2.min.js',
			'plugins/bootstrap-wysihtml5/wysihtml5-0.3.0.js',
			'plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.js',
			'plugins/bootstrap-tag/bootstrap-tagsinput.min.js',
			'plugins/boostrap-clockpicker/bootstrap-clockpicker.min.js',
			'plugins/dropzone/dropzone.min.js',
			'js/form_elements.js'
		);

        $data['listContract'] = $this->contract = array(
            "none"     => '-',
            "Achat" => 'Achat',
            "Prêt"  => 'Prêt',
            "PAO"   => 'Prêt avec option achat'
        );

        //$data['postUsers'] = $this->news_model->getListUsers();

		$id = $this->input->post("id_comment");
		$idpseudo = $this->input->post("id_pseudo");

		$data["classSelect"] = array(
	        'class'   		=> 'form-control'
		);

        $data['rubrique'] = $this->news_model->get_listRubrique();
        $data['section'] = $this->news_model->get_listSection();
		$data['matchs'] = $this->games_model->listGame(1);
        $data['clubs'] = $this->games_model->getListClubs();
		$data['players'] = $this->games_model->getListPlayers();
		$data['stories'] = $this->news_model->getListStory();
		$data["users"] = $this->news_model->getListUsers();

		if(isset($id)) {
			$data["update"] = $this->news_model->updateValid($id, $idpseudo, 1);
		}

		$data["idcomment"] = $this->input->post("id_comment");

		
		$this->load->view('back/news', $data);
	}	
	
	public function editNews($id)
	{

		$this->title = 'Le Meilleur du PSG - Rédiger un article';
		$this->description = "Le back-office du site Le Meilleur du PSG";
		$this->type = "edit";
		$this->type2 = "Modifier";

		$data["id"] = $id;

		$data["type"] = $this->type;
		$data["type2"] = $this->type2;

		$data['dependenciesCSS'] = $this->dependenciesCSS;
		$data['dependenciesJS'] = $this->dependenciesJS;

		$data['requireCSS'] = $this->requireCSS = array(
			'plugins/pace/pace-theme-flash.css',
			'plugins/bootstrapv3/css/bootstrap.min.css',
			'plugins/bootstrapv3/css/bootstrap-theme.min.css',
			'plugins/animate.min.css',
			'plugins/jquery-scrollbar/jquery.scrollbar.css',
			'webarch/css/webarch.css'
		);

		$data['requirejs'] = $this->requirejs = array(
			'plugins/bootstrap-datepicker/js/bootstrap-datepicker.js',
			'plugins/bootstrap-timepicker/js/bootstrap-timepicker.min.js',
			'plugins/jquery-inputmask/jquery.inputmask.min.js',
			'plugins/jquery-autonumeric/autoNumeric.js',
			'plugins/ios-switch/ios7-switch.js',
			'plugins/bootstrap-select2/select2.min.js',
			'plugins/bootstrap-wysihtml5/wysihtml5-0.3.0.js',
			'plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.js',
			'plugins/bootstrap-tag/bootstrap-tagsinput.min.js',
			'plugins/boostrap-clockpicker/bootstrap-clockpicker.min.js',
			'plugins/dropzone/dropzone.min.js',
			'js/form_elements.js'
		);

		$idcomment = $this->input->post("id_comment");
		$idpseudo = $this->input->post("id_pseudo");

		$data["classSelect"] = array(
	        'class'   		=> 'form-control dropzone'
		);

		$data["news"] = $this->news_model->get_news_id($id);

		$data['rubrique'] = $this->news_model->get_listRubrique();
		$data['section'] = $this->news_model->get_listSection();
		$data['matchs'] = $this->games_model->listGame(1);
		$data['clubs'] = $this->games_model->getListClubs();
		$data['players'] = $this->games_model->getListPlayers();
		$data["users"] = $this->news_model->getListUsers();
        $data['postPlayers'] = $this->news_model->getPostPlayer($id);
        $data['postTeams'] = $this->news_model->getPostTeam($id);
        $data['postMatchs'] = $this->news_model->getPostMatch($id);

        $data['postMercato'] = $this->news_model->getPostMercato($id);

        $data['listContract'] = $this->contract = array(
            "none"     => '-',
            "Achat" => 'Achat',
            "Prêt"  => 'Prêt',
            "PAO"   => 'Prêt avec option achat'
        );

        foreach ($data['postMercato'] as $value) {
            $data['mercatoIdPlayer'] = $value['id_player'];
            $data['mercatoIdTeam2'] = $value['id_team2'];
            $data['mercatoTypeContract'] = $value['type_contract'];
        }

        $data['postUsers'] = $this->news_model->getPostUser($id);

		$data['stories'] = $this->news_model->getListStory();

        foreach ($data['postPlayers'] as $value) {
            $data['postPlayer'] = explode(',', $value['id_players']);
        }        

        foreach ($data['postTeams'] as $value) {
            $data['postTeam'] = explode(',', $value['id_teams']);
        }

        foreach ($data['postMatchs'] as $value) {
            $data['postMatch'] = explode(',', $value['id_matchs']);
        }        

        foreach ($data['postUsers'] as $value) {
            $data['postUser'] = explode(',', $value['author_id']);
        }

		if(isset($idcomment)) {
			$data["update"] = $this->news_model->updateValid($idcomment, $idpseudo, 1);
		}

		$data["idcomment"] = $this->input->post("id_comment");

        $this->load->view('back/news', $data);
	}	

	public function formClose()
	{

		$id = $this->input->post("id_comment");
		$idpseudo = $this->input->post("id_pseudo");

		if(isset($id)) {
			$data["update"] = $this->news_model->updateValid($id, $idpseudo, 0);
		}

		$this->load->view('back/formValid');
	}		

	public function formList()
	{

		$type = $this->input->post("type");
		$title = $this->input->post("title");
		$resume = $this->input->post("resume");
		$action = $this->input->post("action");
		$id = $this->input->post("id");

		$slug = $this->news_model->slug($title);

		if(isset($title)) {
			if ($action == "add"):
				if($type == "section"):
					$data["update"] = $this->news_model->addSection($title, $slug);
				elseif($type == "rubrique"):
					$data["update"] = $this->news_model->addRubrique($title, $slug);
				elseif($type == "story"):
					$data["update"] = $this->news_model->addStory($title, $resume, $slug);
				endif;

			$this->session->set_flashdata('success', $title." a bien été ajouté");
			
			elseif($action == "edit"):
				if($type == "section"):
					$data["update"] = $this->news_model->editSection($id, $title, $slug);
				elseif($type == "rubrique"):
					$data["update"] = $this->news_model->editRubrique($id, $title, $slug);
				elseif($type == "story"):
					$data["update"] = $this->news_model->editStory($id, $title, $resume, $slug);
				endif;
			endif;

			$this->session->set_flashdata('success', $title." a bien été modifié");
		}

		$this->load->view('back/formValid');
	}	

	public function formDelete()
	{

		$id = $this->input->post("id_comment");
		$idpseudo = $this->input->post("id_pseudo");

		if(isset($id)) {
			$data["update"] = $this->news_model->updateValid($id, $idpseudo, 4);
		}

		$this->load->view('back/formValid');
	}

    public function success()
    {
        $this->title = 'Le Meilleur du PSG - Rédiger un article';
        $this->description = "Le back-office du site Le Meilleur du PSG";

        $data['dependenciesCSS'] = $this->dependenciesCSS;
        $data['dependenciesJS'] = $this->dependenciesJS;

        $data['requireCSS'] = $this->requireCSS = array(
            'plugins/jquery-slider/css/jquery.sidr.light.css',
            'plugins/jquery-ricksaw-chart/css/rickshaw.css',
            'plugins/Mapplic/mapplic/mapplic.css',
            'plugins/pace/pace-theme-flash.css',
            'plugins/bootstrapv3/css/bootstrap.min.css',
            'plugins/bootstrapv3/css/bootstrap-theme.min.css',
            'plugins/animate.min.css',
            'plugins/jquery-scrollbar/jquery.scrollbar.css',
            'plugins/ios-switch/ios7-switch.css',
            'webarch/css/webarch.css'
        );

        $data['requirejs'] = $this->requirejs = array(
            'js/support_ticket.js'
        );


        return $this->load->view('back/formtest', $data);
    }

    public function storyList() {

        $this->title = 'Le Meilleur du PSG - Todo List';
        $this->description = "Le back-office du site Le Meilleur du PSG";

        $data['dependenciesCSS'] = $this->dependenciesCSS;
        $data['dependenciesJS'] = $this->dependenciesJS;

        $data['requireCSS'] = $this->requireCSS = array(
            'plugins/jquery-slider/css/jquery.sidr.light.css',
            'plugins/jquery-ricksaw-chart/css/rickshaw.css',
            'plugins/Mapplic/mapplic/mapplic.css',
            'plugins/pace/pace-theme-flash.css',
            'plugins/bootstrapv3/css/bootstrap.min.css',
            'plugins/bootstrapv3/css/bootstrap-theme.min.css',
            'plugins/animate.min.css',
            'plugins/jquery-scrollbar/jquery.scrollbar.css',
            'plugins/ios-switch/ios7-switch.css',
            'webarch/css/webarch.css'
        );

        $data['requirejs'] = $this->requirejs = array(
            'js/support_ticket.js'
        );

        $data["list_news"] = $this->news_model->getListStory();

        $data["title"] = $this->form = array(
            'name'          => 'title',
            'id'            => 'title',
            'placeholder'   => 'Titre',
            'class'   		=> 'form-control',
        );

        $data["resume"] = $this->form = array(
            'name'          => 'resume',
            'id'            => 'resume',
            'placeholder'   => 'Ajoute un résume',
            'class'   		=> 'form-control',
            'row'			=> '8'
        );

        $data["type"] = "story";
        $data["action"] = "add";
        $data["list"] = $this->news_model->getListStory();


        $this->load->view('back/list', $data);
    }

    public function story($id) {

        $this->title = 'Le Meilleur du PSG - Todo List';
        $this->description = "Le back-office du site Le Meilleur du PSG";

        $data['dependenciesCSS'] = $this->dependenciesCSS;
        $data['dependenciesJS'] = $this->dependenciesJS;

        $data['requireCSS'] = $this->requireCSS = array(
            'plugins/jquery-slider/css/jquery.sidr.light.css',
            'plugins/jquery-ricksaw-chart/css/rickshaw.css',
            'plugins/Mapplic/mapplic/mapplic.css',
            'plugins/pace/pace-theme-flash.css',
            'plugins/bootstrapv3/css/bootstrap.min.css',
            'plugins/bootstrapv3/css/bootstrap-theme.min.css',
            'plugins/animate.min.css',
            'plugins/jquery-scrollbar/jquery.scrollbar.css',
            'plugins/ios-switch/ios7-switch.css',
            'webarch/css/webarch.css'
        );

        $data['requirejs'] = $this->requirejs = array(
            'js/support_ticket.js'
        );

        $data["list_news"] = $this->news_model->get_list_news_story($id, 0);
        $data["list"] = $this->news_model->getListStory();

        $data["title"] = $this->form = array(
            'name'          => 'title',
            'id'            => 'title',
            'placeholder'   => 'Titre',
            'class'   		=> 'form-control',
        );

        $data["resume"] = $this->form = array(
            'name'          => 'resume',
            'id'            => 'resume',
            'placeholder'   => 'Ajoute un résume',
            'class'   		=> 'form-control',
            'row'			=> '8'
        );

        $data["type"] = "story";
        $data["action"] = "add";
		$data["list_sections"] = $this->news_model->get_ListSection();
		$data["list"] = $this->news_model->get_ListRubrique();
        $this->slug = $id;

        $this->load->view('back/listnews', $data);
    }

    public function editStory($slug) {

        $this->title = 'Le Meilleur du PSG - Section';
        $this->description = "Le back-office du site Le Meilleur du PSG";

        $data['dependenciesCSS'] = $this->dependenciesCSS;
        $data['dependenciesJS'] = $this->dependenciesJS;

        $data['requireCSS'] = $this->requireCSS = array(
            'plugins/jquery-slider/css/jquery.sidr.light.css',
            'plugins/jquery-ricksaw-chart/css/rickshaw.css',
            'plugins/Mapplic/mapplic/mapplic.css',
            'plugins/pace/pace-theme-flash.css',
            'plugins/bootstrapv3/css/bootstrap.min.css',
            'plugins/bootstrapv3/css/bootstrap-theme.min.css',
            'plugins/animate.min.css',
            'plugins/jquery-scrollbar/jquery.scrollbar.css',
            'plugins/ios-switch/ios7-switch.css',
            'webarch/css/webarch.css'
        );

        $data['requirejs'] = $this->requirejs = array(
            'js/support_ticket.js'
        );

        $data["list_news"] = $this->news_model->getListStory($slug, 0);
        $data["list"] = $this->news_model->getListStory();
        $data["story"] = $this->news_model->getStory($slug);

        foreach ($data["story"] as $value) {
            $id = $value["id"];
            $story = $value["name"];
            $resume = $value["resume"];
        }

        $data["title"] = $this->form = array(
            'name'          => 'title',
            'id'            => 'title',
            'placeholder'   => 'Titre',
            'class'   		=> 'form-control',
            'value'			=>  $story,
        );

        $data["resume"] = $this->form = array(
            'name'          => 'resume',
            'id'            => 'resume',
            'placeholder'   => 'Ajoute un résume',
            'class'   		=> 'form-control',
            'row'			=> '8',
            'value'			=>  $resume,
        );

        $data["id"] = $id;

        $data["type"] = "story";
        $data["action"] = "edit";
        $this->slug = $slug;

        $this->load->view('back/list', $data);
    }

	public function deleteForm($table, $id) {

		$data["update"] = $this->news_model->deleteForm($id, $table);

        $this->session->set_flashdata('success', "L'article a bien été supprimé");
		$this->load->view('back/formValid', $data);
	}

}
